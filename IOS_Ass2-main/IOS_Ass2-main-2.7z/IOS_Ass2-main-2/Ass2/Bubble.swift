//
//  Bubble.swift
//  Ass2
//
//  Created by Martin Liang on 27/4/21.
//

import Foundation
import UIKit

struct Bubble{
    
    init() {}
    
    //var Colour: Int
    //var X_Co: Int
    //var Y_Co: Int
    //var Point: Int
    
    func getImage(colour: String) -> UIImage? {
        let image = UIImage(named: "red.png")
        return image
    }
    
    func getCoords(X_Co: Int, Y_Co: Int, existingBubbles: Array<Int>) -> Array<Int>{
        
        
        return [0,0];
    }
    
    func getPoints() -> Int{
        
        
        return 0
    }
}
